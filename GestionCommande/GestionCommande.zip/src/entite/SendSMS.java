/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

/**
 *
 * @author user
 */
public class SendSMS {
    
    
    public static final String ACCOUNT_SID = "AC89887038d2845497a6c26db5fa4e1e79";     /// 
    public static final String AUTH_TOKEN = "7b37b19a526a32ca9cc988f114d603fb"; ///   
    public static final String TWILIO_NUMBER = "++15674302576";
    
    public static void sendSms(String code,String num) {

        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

       String phoneNumber = "+216"+num;
       String msg="Votre code ugo est "+code;
      //  Message message = Message.creator(new PhoneNumber(phoneNumber),new PhoneNumber(TWILIO_NUMBER),"garage ajouter").create();
         Message message = Message.creator(new PhoneNumber(phoneNumber), new PhoneNumber(TWILIO_NUMBER), code).create();
        
        System.out.println(message.getSid());
	}
    
}
