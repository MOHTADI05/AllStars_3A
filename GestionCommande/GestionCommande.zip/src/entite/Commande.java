/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entite;
import java.util.List;
import service.IServiceCommande;

/**
 *
 * @author oumayma
 */
public class Commande  {
    private int id_cmd;
    private String adress;
    private int num_cl;
    private String nom_cl;
    private String prenom_cl;
    private float prix ;
    private String mail_cl;

    public Commande() {
    }

    public Commande(String adress, int num_cl, String nom_cl, String prenom_cl, float prix, String mail_cl) {
        this.adress = adress;
        this.num_cl = num_cl;
        this.nom_cl = nom_cl;
        this.prenom_cl = prenom_cl;
        this.prix = prix;
        this.mail_cl = mail_cl;
    }

    public Commande(int id_cmd, String adress, int num_cl, String nom_cl, String prenom_cl, int prix, String mail_cl) {
        this.id_cmd = id_cmd;
        this.adress = adress;
        this.num_cl = num_cl;
        this.nom_cl = nom_cl;
        this.prenom_cl = prenom_cl;
        this.prix = prix;
        this.mail_cl = mail_cl;
    }

    public int getId_cmd() {
        return id_cmd;
    }

    public String getAdress() {
        return adress;
    }

    public int getNum_cl() {
        return num_cl;
    }

    public String getNom_cl() {
        return nom_cl;
    }

    public String getPrenom_cl() {
        return prenom_cl;
    }

    public float getPrix() {
        return prix;
    }

    public String getMail_cl() {
        return mail_cl;
    }

    public void setId_cmd(int id_cmd) {
        this.id_cmd = id_cmd;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public void setNum_cl(int num_cl) {
        this.num_cl = num_cl;
    }

    public void setNom_cl(String nom_cl) {
        this.nom_cl = nom_cl;
    }

    public void setPrenom_cl(String prenom_cl) {
        this.prenom_cl = prenom_cl;
    }

    public void setPrix(float prix) {
        this.prix = prix;
    }

    public void setMail_cl(String mail_cl) {
        this.mail_cl = mail_cl;
    }

    public Commande(int id_cmd) {
        this.id_cmd = id_cmd;
    }
    

    @Override
    public String toString() {
        return "Commande{" + "id_cmd=" + id_cmd + ", adress=" + adress + ", num_cl=" + num_cl + ", nom_cl=" + nom_cl + ", prenom_cl=" + prenom_cl + ", prix=" + prix + ", mail_cl=" + mail_cl + '}';
    }

    

    
    
}
