/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entite.Commande;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import utils.DataSource;

/**
 *
 * @author oumayma
 */
public class ServiceCommande implements IServiceCommande<Commande> {
    
    
    private Connection conn;
    PreparedStatement stmt;
    PreparedStatement ste;

    public ServiceCommande() {
         conn = DataSource.getInstance().getCnx();
    }
 // ---------------------------------- Ajouter Commande ---------------------------------------//

    /**
     *
     * @param c
     * @return
     */
    @Override
     public void ajouterCommande(Commande c) {
        
    
          try {
              
        String sql ="INSERT INTO commande (id_cmd,address,num_client,nom_client,prenom_client,prix,mail_client) Values(?,?,?,?,?,?,?)";
        stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        
        // Set the parameter values for the INSERT statement
        
      
           ste=conn.prepareStatement(sql);
             stmt.setInt(1, c.getId_cmd());
             stmt.setString (2,c.getAdress());
             stmt.setInt(3, c.getNum_cl());
             stmt.setString(4,c.getNom_cl());
             stmt.setString(5, c.getPrenom_cl());
             stmt.setFloat(6,c.getPrix());
             stmt.setString(7,c.getMail_cl());
             stmt.executeUpdate();
           System.out.println("Commande Ajoutée avec succés !");
           }catch (SQLException e) {
           Logger.getLogger(ServiceCommande.class.getName()).log(Level.SEVERE, null, e);
              }
     }
    

        //--------------------------------------- Afficher Commande ------------------------------------------------//
    @Override
    
     public List<Commande> afficherCommande(){
        List<Commande> commande =  new ArrayList<>();
      String sql="select * from commande";
      
      try
      {
          ste=conn.prepareStatement(sql);
          
          ResultSet rs=ste.executeQuery();
                  while(rs.next()){
                      Commande C = new Commande();
                      C.setId_cmd(rs.getInt("id_cmd"));
                      C.setAdress(rs.getString("address"));
                      C.setNum_cl(rs.getInt("num_client"));
                      C.setNom_cl(rs.getString("nom_client"));
                      C.setPrenom_cl(rs.getString("prenom_client"));
                      C.setPrix(rs.getFloat("prix"));
                      C.setMail_cl(rs.getString("mail_client"));
                      //commande.add(c);
                      System.out.println("id commande : "+C.getId_cmd()+ "\n Adresse de livraison : "+C.getAdress()+ "\n Numero de telephone : "+C.getNum_cl()+"\n Nom du client : " +C.getNom_cl()+ "\n Prenom du client : "+C.getPrenom_cl()+"\n Prix: "+C.getPrix()
                              +"\n Mail du client:"+C.getMail_cl()) ;
                  }
      }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
      return commande;
    }
 
  
    
 // ---------------------------------- Modifier Commande ---------------------------------------//

    @Override
    public void modifierCommande(Commande e) {

       
            try {
          
         String req = "UPDATE `commande` SET  `id_cmd`='" 
                 + e.getId_cmd()+ "',`address`='" + e.getAdress()+
                 "',`num_client`='" 
                 + e.getNum_cl()+ "', `nom_client`='" 
                 + e.getNom_cl()+ "',`prenom_client`='"
                 + e.getPrenom_cl()+
                 "',`prix`='"+e.getPrix()+"',`mail_client`='"+e.getMail_cl()+
                 "' WHERE id_cmd=" + e.getId_cmd();
         
            Statement st = conn.createStatement();
            st.executeUpdate(req);
            System.out.println("La commande  est modifée !");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
       
       
       
       
        
        
        
    }
 // ---------------------------------- Supprimer Commande ---------------------------------------//

    @Override
    public void supprimerCommande(int id_cmd) {
       String sql = "DELETE from commande where id_cmd = '"+id_cmd+"' ";
        try{
           Statement st= conn.createStatement();
           st.executeUpdate(sql);
           System.out.println("Commande supprimée avec succés !");
       }catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }  
    }
    
 // ---------------------------------- chercher Commande ---------------------------------------//


    @Override
    public List<Commande> displayByID(int id_cmd)
{
        
            List <Commande> myList= new ArrayList<>();

    String req="select * from commande where id_cmd='"+id_cmd+"' ";

    try {
        Statement st = conn.createStatement();
        ResultSet rs=st.executeQuery(req);
        while(rs.next()){
        
                      Commande C = new Commande();
                      C.setId_cmd(rs.getInt("id_cmd"));
                      C.setAdress(rs.getString("address"));
                      C.setNum_cl(rs.getInt("num_client"));
                      C.setNom_cl(rs.getString("nom_client"));
                      C.setPrenom_cl(rs.getString("prenom_client"));
                      C.setPrix(rs.getFloat("prix"));
                      C.setMail_cl(rs.getString("mail_client"));
                      myList.add(C);

        }
    } catch (SQLException ex) {
        System.err.println(ex.getMessage());
    }
    return myList;
        
        
    }
       
    public ObservableList <Commande> afficherCommande2() {
             String querry ="SELECT * FROM `commande`";

ObservableList <Commande> ch = FXCollections.observableArrayList();
    
        try {
        Statement stm =conn.createStatement();
     
        ResultSet rs= stm.executeQuery(querry);
        
        while(rs.next()){
            Commande c = new Commande();

                      c.setId_cmd(rs.getInt("id_cmd"));
                      c.setAdress(rs.getString("address"));
                      c.setNum_cl(rs.getInt("num_client"));
                      c.setNom_cl(rs.getString("nom_client"));
                      c.setPrenom_cl(rs.getString("prenom_client"));
                      c.setPrix(rs.getFloat("prix"));
                      c.setMail_cl(rs.getString("mail_client"));

            
            ch.add(c);
        }
        
    } catch (SQLException ex) {
            System.out.println(ex.getMessage()); 
    
    }
     return ch ;   
    }
    
    public ObservableList <Commande> afficherCommandeById(int id_cmd) {
     String querry ="select * from commande where id_cmd='"+id_cmd+"' ";

ObservableList <Commande> ch = FXCollections.observableArrayList();
    
        try {
        Statement stm =conn.createStatement();
     
        ResultSet rs= stm.executeQuery(querry);
        
        while(rs.next()){
       Commande c = new Commande();
                      c.setId_cmd(rs.getInt("id_cmd"));
                      c.setAdress(rs.getString("address"));
                      c.setNum_cl(rs.getInt("num_client"));
                      c.setNom_cl(rs.getString("nom_client"));
                      c.setPrenom_cl(rs.getString("prenom_client"));
                      c.setPrix(rs.getFloat("prix"));
                      c.setMail_cl(rs.getString("mail_client"));
                      ch.add(c);
        }
        
    } catch (SQLException ex) {
            System.out.println(ex.getMessage()); 
    
    }
     return ch ;   
    }

    public boolean existeCommande(int id) {
        try {
        PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM commande WHERE id_cmd = ?");
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            int count = rs.getInt(1);
            return count > 0;
        }
        return false;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
    }
    
   


    public Commande getCommande(int id) {
    PreparedStatement stmt = null;
    ResultSet rs = null;
    Commande commande = null;

    try {
        stmt = conn.prepareStatement("SELECT * FROM commande WHERE id_cmd = ?");
        stmt.setInt(1, id);
        rs = stmt.executeQuery();

        if (rs.next()) {
            commande = new Commande(
                rs.getInt("id_cmd"),
                rs.getString("address"),
                rs.getInt("num_client"),
                rs.getString("nom_client"),
                rs.getString("prenom_client"), (int) rs.getFloat("prix"),
                rs.getString("mail_client")
            );
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        // Close resources
    }

    return commande;
}

    public Commande rechercherCommande(int id) {
    String sql = "SELECT * FROM commande WHERE id_cmd = ?";
    try {
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            Commande commande = new Commande();
            commande.setId_cmd(rs.getInt("id_cmd"));
            commande.setAdress(rs.getString("address"));
            commande.setNom_cl(rs.getString("nom_client"));
            commande.setPrenom_cl(rs.getString("prenom_client"));
            commande.setMail_cl(rs.getString("mail_client"));
            commande.setPrix(rs.getFloat("prix"));
            commande.setNum_cl(rs.getInt("num_client"));
      
            return commande;
        } else {
            return null;
        }
    } catch (SQLException ex) {
        Logger.getLogger(ServiceCommande.class.getName()).log(Level.SEVERE, null, ex);
        return null;
    }
}
    ///////////////////////afficherCommandeByNom///////////////////////////////////////////
    
    public ObservableList <Commande> afficherCommandeByNom(String nom_client) {
     String query ="select * from commande where nom_client=?";

ObservableList <Commande> ch = FXCollections.observableArrayList();
    
        try {
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, nom_client);
        ResultSet rs = stmt.executeQuery();
        
        while(rs.next()){
            Commande c = new Commande();

                      c.setId_cmd(rs.getInt("id_cmd"));
                      c.setAdress(rs.getString("address"));
                      c.setNum_cl(rs.getInt("num_client"));
                      c.setNom_cl(rs.getString("nom_client"));
                      c.setPrenom_cl(rs.getString("prenom_client"));
                      c.setPrix(rs.getFloat("prix"));
                      c.setMail_cl(rs.getString("mail_client"));
            
            ch.add(c);
        }
        
    } catch (SQLException ex) {
            System.out.println(ex.getMessage()); 
    
    }
     return ch ;   
    }
    
    ////////////////////////////////////////affichercommandeByPrenom///////////////////////////////////////////
    
     public ObservableList<Commande> affichercommandeByPrenom(String prenom_client) {
    String query = "SELECT * FROM commande WHERE prenom_client = ?";
    ObservableList<Commande> commande = FXCollections.observableArrayList();
    
    try {
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, prenom_client);
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {
            Commande c = new Commande();
                      c.setId_cmd(rs.getInt("id_cmd"));
                      c.setAdress(rs.getString("address"));
                      c.setNum_cl(rs.getInt("num_client"));
                      c.setNom_cl(rs.getString("nom_client"));
                      c.setPrenom_cl(rs.getString("prenom_client"));
                      c.setPrix(rs.getFloat("prix"));
                      c.setMail_cl(rs.getString("mail_client"));
            
            commande.add(c);
        }
    } catch (SQLException ex) {
        System.out.println(ex.getMessage()); 
    }
    
    return commande;
}

     public Commande readById(int id) {
        Commande c = null; // Déclarer la variable p en dehors du bloc if

    try {
        PreparedStatement statement = conn.prepareStatement("SELECT * FROM commande WHERE id_cmd = "+id);
        ResultSet rs = statement.executeQuery();

        if (rs.next()) {
            
            c = new Commande (rs.getInt(1), 
                          rs.getString(2), 
                          rs.getInt(3), 
                          rs.getString(4),
                          rs.getString(5), (int) rs.getFloat(6),
                          rs.getString(7)
            );
                          
           //System.out.print("aaaa:"+p);
                    }
    } catch (SQLException e) {
            // Gérer l'exception SQLException
            System.out.print(e.getMessage());
            Logger.getLogger(ServiceCommande.class.getName()).log(Level.SEVERE, null, e);
    }
    return c;
    }
    
      public void supprimerCommande(Commande e) throws SQLException {
               String req="delete from commande where id_cmd=?";
       
       // try {
            
            PreparedStatement stm;
            stm=conn.prepareStatement(req);
            stm.setInt(1,e.getId_cmd());
            int i=stm.executeUpdate();
            System.out.println(i+ " Commande  suprimé");
        //} catch (SQLException ex) {
            //System.out.println(ex.getMessage());
        //}
    }
      
      public Iterable<Commande> getListeCommande() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
      public ObservableList<Commande> search2(String searchTerm) {
        ObservableList<Commande> list = FXCollections.observableArrayList();
        try {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM commande");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Commande commande = new Commande(

                         rs.getInt(1), 
                          rs.getString(2), 
                          rs.getInt(3), 
                          rs.getString(4),
                          rs.getString(5), (int) rs.getFloat(6),
                          rs.getString(7)
            
                );
                list.add(commande);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
      
      public ObservableList<Commande> search3(String searchTerm) {
    ObservableList<Commande> list = FXCollections.observableArrayList();
    try {
        String query = "SELECT * FROM commande WHERE nom_client LIKE ?";
        PreparedStatement preparedStatement = conn.prepareStatement(query);
        preparedStatement.setString(1, searchTerm + "%");
        ResultSet rs = preparedStatement.executeQuery();
        while (rs.next()) {
            Commande commande = new Commande(
                          rs.getInt(1), 
                          rs.getString(2), 
                          rs.getInt(3), 
                          rs.getString(4),
                          rs.getString(5), (int) rs.getFloat(6),
                          rs.getString(7)
            );
            list.add(commande);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return list;
}
public Commande getCommandeById(int id_cmd) {
    Commande commande = null;
    String sql = "SELECT * FROM commande WHERE id_cmd = ?";
    try {
        PreparedStatement stm = conn.prepareStatement(sql);
        stm.setInt(1, id_cmd);
        ResultSet rs = stm.executeQuery();
        if (rs.next()) {
            commande = new Commande();
            commande.setId_cmd(rs.getInt("id_cmd"));
            commande.setAdress(rs.getString("address"));
            commande.setNum_cl(rs.getInt("num_client"));
            commande.setNom_cl(rs.getString("nom_client"));
            commande.setPrenom_cl(rs.getString("prenom_client"));
            commande.setPrix(rs.getFloat("prix"));
            commande.setMail_cl(rs.getString("mail_client"));
        }
    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
    return commande;
}




}