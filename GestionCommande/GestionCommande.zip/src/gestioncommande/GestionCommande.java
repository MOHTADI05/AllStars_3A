/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestioncommande;
import entite.Commande;
import entite.Livraison;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import utils.DataSource ;
import service.ServiceCommande;
import service.ServiceLivraison;


/**
 *
 * @author oumayma
 */
public class GestionCommande {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        DataSource ds1 = DataSource.getInstance();
        //System.out.println(ds1);
    Connection conn = null; // Initialize your database connection object here
    
    Livraison l = new Livraison();
    l.setDate_liv(LocalDate.now()); // Set the delivery date to today's date
    l.setTransporteur("Ujjjjj"); // Set the transport company name to "UPS"
    l.setAddress_liv("123 Main St, Anytown USA"); // Set the delivery address
    Commande c = new Commande();
    c.setId_cmd(30); // Set the order ID to 1
    l.setCmd(c); // Associate the delivery with the order
    ServiceLivraison sL = new ServiceLivraison(); 
    //sL.ajouterLivraison(l);
   // System.out.println(sL.afficherLivraison2());
  //sL.supprimerLivraison(l);
  // Créer un objet Livraison à supprimer

l.setId_liv(1); // Id de la livraison à supprimer

// Appeler la fonction supprimerLivraison

    sL.supprimerLivraison(l);


    
//    
//        Livraison l = new Livraison(LocalDate.now(),"rrrr","123 Main St, Anytown USA");
//
//    
//    ServiceLivraison sL = new ServiceLivraison(); // Initialize your service object here
//    
//  //  Livraison r = new Livraison (id_liv,date_liv,transorteur,address_liv,id_cmd);
//    sL.modifierLivraison(l,7);
    //serviceLivraison.ajouterLivraison(l); // Call the method to add the delivery to the database
    //System.out.println(serviceLivraison.afficherLivraison().toString());
  //serviceLivraison.supprimerLivraison(111);
  
  
  
       Commande offre = new Commande(30,"aryena",54050740,"oumayma","baha",888,"OYFF"); 
    ServiceCommande o1 =new ServiceCommande() ;
    //o1.modifierCommande(offre);
//o1.ajouterCommande(offre);
//     LocalDate ld=LocalDate.of(2004, 12, 13);
//     //(LocalDate date_liv, String transporteur, String address_liv, Commande cmd)
//    Livraison   e  = new Livraison (ld,"aramex","nabel",offre);
//    ServiceLivraison se = new ServiceLivraison();
//    se.ajouterLivraison(e);
       
//       Commande c1;
      //Commande c3;
//        c1 = new Commande ("aryena",234,"ahmes","aze",12,"OYFF");
        //c3 = new Commande ("az",34,"dfg","ghj",14,"vbn");
//       ServiceCommande c2=new ServiceCommande();
       //ServiceCommande c4=new ServiceCommande();
       //c4.ajouterCommande(c3);
      // c2.ajouterCommande( c1);
       // c2.afficherCommande();
        //System.out.println(c2.displayByID(15));
        //c3 = new Commande ("gt",34,"dfg","ghj",14,"vbn");
    //c2.modifierCommande(new Commande( 1,"bizert",234,"ahmed","aze",12,"OYFF"));
    //System.out.println(c2.displayByID(2)) ;
    // c2.afficherCommande2();
   // System.out.println(c2.getCommande(5));
        
        //c2.supprimerCommande(1);
        //Panier p1 ;
        //p1 = new Panier (3, 20, "hjkl");
        //ServicePanier p2 = new ServicePanier();
        //p2.ajouterPanier(p1);
        //p2.afficherPanier();
        //p2.modifierPanier( new Panier (1,3,45,"aaaa"));
          //System.out.println(p2.displayByID(2));
        
        //p2.supprimerPanier(1);
        
        
    // Créer une instance de la classe ServiceLivraison
  //  ServiceLivraison serviceLivraison = new ServiceLivraison();
    
    // Créer une instance    de l'objet Livraison avec des valeurs arbitraires
    //Livraison livraison = new Livraison("2023-02-22", "Transporteur X", "1 rue de la Livraison", new Commande(1234));
    
    // Appeler la méthode ajouterLivraison en passant l'objet Livraison comme paramètre
   // serviceLivraison.ajouterLivraison(livraison);


        
        
        
        
        
        
}   
}
    

