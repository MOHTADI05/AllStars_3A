/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import entite.Commande;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import service.ServiceCommande;

/**
 * FXML Controller class
 *
 * @author user
 */
public class EditCommandeController implements Initializable {

    @FXML
    private TextField addFieldM;
    @FXML
    private TextField nomFieldM;
    @FXML
    private TextField prenomFieldM;
    @FXML
    private TextField prixFieldM;
    @FXML
    private TextField mailFieldM;
    @FXML
    private TextField numFieldM;
    @FXML
    private TextField idM;
    @FXML
    private Button btnEdit;
    @FXML
    private Button toAFFM;
    @FXML
    private Button To_rubrique;
           @FXML
    private Label id;
        
       private int  idC;  
      Commande r = new Commande();
        
        
    /**
     * Initializes the controller class.
     */
        
         public void tarata()
       {
        
        ServiceCommande su = new ServiceCommande();
        r=su.readById(idC);
        //System.out.print(e);
       }
         
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    
 ServiceCommande su = new ServiceCommande() ; 

    @FXML
    private void ModifierCommande(ActionEvent event) throws IOException {
       
     Commande c = new Commande();
     ServiceCommande su = new ServiceCommande() ; 
     
        c.setId_cmd(idC);
        c.setAdress(addFieldM.getText());
        c.setNom_cl(nomFieldM.getText());
        c.setPrenom_cl(prenomFieldM.getText());
        c.setMail_cl(mailFieldM.getText());
        c.setNum_cl(Integer.parseInt(numFieldM.getText()));
     
        try {
        c.setPrix(Float.parseFloat(prixFieldM.getText()));
    } catch (NumberFormatException r) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Le champ prix doit étre un nombre !");
        alert.showAndWait();
        return;
    }
     if (!numFieldM.getText().matches("\\d{8}")) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("Erreur");
    alert.setHeaderText(null);
    alert.setContentText("Le champ numField doit contenir exactement 8 chiffres !");
    alert.showAndWait();
    return;
}
  r.setNum_cl(Integer.parseInt(numFieldM.getText()));
// try {
//    c.setNum_cl(Integer.parseInt(numFieldM.getText()));
//} catch (NumberFormatException r) {
//    Alert alert = new Alert(Alert.AlertType.ERROR);
//    alert.setTitle("Erreur");
//    alert.setHeaderText(null);
//    alert.setContentText("Le champ nb_place doit être un nombre entier!");
//    alert.showAndWait();
//    return;
//}
        
     
        
        su.modifierCommande(c);
      Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText("modification éffectuée");
                alert.showAndWait();
       
}

    

    @FXML
    private void Afficher2(ActionEvent event) throws IOException {
               FXMLLoader loader = new FXMLLoader(getClass().getResource("AfficherCommande.fxml"));
                Parent root = loader.load();
               AfficherCommandeController aa = loader.getController();
                toAFFM.getScene().setRoot(root);
        
    }

    @FXML
    private void pass_rubrique(ActionEvent event) throws IOException {
             FXMLLoader loader = new FXMLLoader(getClass().getResource("RubriqueCommande.fxml"));
                Parent root = loader.load();
               RubriqueCommandeController aa = loader.getController();
                To_rubrique.getScene().setRoot(root);
        
    }

   public void initData(int data) {
       this.idC=data;
      String stringNumber = Integer.toString(idC);

      id.setText(stringNumber);
      tarata();
      
    addFieldM.setText(r.getAdress());
    nomFieldM.setText(r.getNom_cl());
    prenomFieldM.setText(r.getPrenom_cl());
    prixFieldM.setText(String.valueOf(r.getPrix()));
    mailFieldM.setText(r.getMail_cl());
    numFieldM.setText(String.valueOf(r.getNum_cl()));
            }
}
