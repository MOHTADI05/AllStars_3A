/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import entite.Commande;
import entite.Livraison;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import service.ServiceLivraison;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AddlivraisonController implements Initializable {

    private TextField cmd_Fliv;
    @FXML
    private TextField adress_Fliv;
    @FXML
    private TextField transportFliv;
    @FXML
    private DatePicker date_liv;
    @FXML
    private Button torubLiv;
    @FXML
    private ComboBox<String> cle;
    @FXML
    private Button Ajouter_bliv;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        List<String> id_offre = new ArrayList<>();
    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    try {
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bepro", "root", "");
        stmt = conn.createStatement();
        rs = stmt.executeQuery("SELECT id_cmd FROM commande");
        while (rs.next()) {
            id_offre.add(Integer.toString(rs.getInt("id_cmd")));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     cle.getItems().addAll(id_offre);
        
        
        // TODO
    }    
    
     ServiceLivraison sr = new ServiceLivraison() ;
    Livraison r = new Livraison();
    Commande c = new Commande ();
 
    @FXML
  private void ajouter_Liv(ActionEvent event) throws IOException {
    if ( adress_Fliv.getText().isEmpty() || transportFliv.getText().isEmpty() || 
    date_liv.getValue() == null) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Veuillez remplir tous les champs !");
        alert.showAndWait();}
    else{
    
    r.setAddress_liv(adress_Fliv.getText());
    r.setDate_liv(date_liv.getValue());
    r.setTransporteur(transportFliv.getText());
          String s1 = cle.getSelectionModel().getSelectedItem();
        c.setId_cmd(Integer.parseInt(s1));
        r.setCmd(c);
        sr.ajouterLivraison(r);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
alert.setTitle("Succès");
alert.setHeaderText(null);
alert.setContentText("Votre Livraison est ajoutée !");
alert.showAndWait();
  

} 


   
    
}
  
    @FXML
    private void pass_rub_liv(ActionEvent event) throws IOException {
        
         FXMLLoader loader = new FXMLLoader(getClass().getResource("RubriqueCommande.fxml"));
                Parent root = loader.load();
               RubriqueCommandeController aa = loader.getController();
                torubLiv.getScene().setRoot(root);
    }

    @FXML
    private void cle(ActionEvent event) {
    }

}
