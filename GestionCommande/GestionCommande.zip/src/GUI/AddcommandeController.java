/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import entite.Commande;
import entite.SendSMS;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import service.ServiceCommande;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AddcommandeController implements Initializable {

    @FXML
    private TextField addField;
    @FXML
    private TextField nomField;
    @FXML
    private TextField prenomField;
    @FXML
    private TextField prixField;
    @FXML
    private TextField mailField;
    @FXML
    private TextField numField;
    @FXML
    private Button btnAdd;
    @FXML
    private Button toAFF;
    @FXML
    private Button retour_rub;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    ServiceCommande sr = new ServiceCommande() ;
    Commande r = new Commande();

    @FXML
    private void AjouterCommande(ActionEvent event) {
        
        if (addField.getText().isEmpty() || nomField.getText().isEmpty() || prenomField.getText().isEmpty() || 
        prixField.getText().isEmpty() || mailField.getText().isEmpty() || numField.getText().isEmpty()) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Veuillez remplir tous les champs !");
        alert.showAndWait();
        return;
    }
// Vérification de la validité de l'adresse e-mail
String emailRegex = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
Pattern pattern = Pattern.compile(emailRegex, Pattern.CASE_INSENSITIVE);
Matcher matcher = pattern.matcher(mailField.getText());
if (!matcher.matches()) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("Erreur");
    alert.setHeaderText(null);
    alert.setContentText("Veuillez saisir une adresse e-mail valide !");
    alert.showAndWait();
    
   
    return;
}

r.setAdress(addField.getText());
r.setNom_cl(nomField.getText());
r.setPrenom_cl(prenomField.getText());

    try {
        r.setPrix(Float.parseFloat(prixField.getText()));
    } catch (NumberFormatException e) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erreur");
        alert.setHeaderText(null);
        alert.setContentText("Le champ prix doit étre un nombre !");
        alert.showAndWait();
        return;
    }
r.setMail_cl(mailField.getText());

if (!numField.getText().matches("\\d{8}")) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("Erreur");
    alert.setHeaderText(null);
    alert.setContentText("Le champ numField doit contenir exactement 8 chiffres !");
    alert.showAndWait();
    return;
}
  r.setNum_cl(Integer.parseInt(numField.getText()));


sr.ajouterCommande(r);
SendSMS s = new SendSMS();
        s.sendSms("Votre commande a bien été enregistrer , Elle sera livrer bientot , Merci pour votre confiance !! ", numField.getText());

Alert alert = new Alert(Alert.AlertType.INFORMATION);
alert.setTitle("Succès");
alert.setHeaderText(null);
alert.setContentText("Votre Commande est ajoutée !");
alert.showAndWait();
        
    
        
        
        
    }

    @FXML
    private void Afficher(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AfficherCommande.fxml"));
                Parent root = loader.load();
               AfficherCommandeController aa = loader.getController();
                toAFF.getScene().setRoot(root);
        
        
    }
    
    
    @FXML
    private void retour_rub(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("RubriqueCommande.fxml"));
                Parent root = loader.load();
               RubriqueCommandeController aa = loader.getController();
                toAFF.getScene().setRoot(root);
        
        
    }
    
}
